function wansite_assets() {
  wp_enqueue_style( 'wansite-stylesheet', get_template_directory_uri() . '/dist/css/bundle.css', array(), '1.0.0', 'all' );
}
add_action('wp_enqueue_scripts', 'wansite_assets');